import axios from 'axios';
import './App.css';

function App() {
  const base = 'http://localhost:3001/plan-list-temp-server';
  const API_KEY = '4NKQ3-815C2-8T5Q2-16318-55301';
  const token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhcGlfa2V5IjoiNE5LUTMtODE1QzItOFQ1UTItMTYzMTgtNTUzMDEiLCJzdWIiOjQzOCwiaXNzIjoiaHR0cHM6Ly9kZXZjb3JlMDIuY2ltZXQuaW8vdjEvZ2VuZXJhdGUtdG9rZW4iLCJpYXQiOjE2NzQ0OTk1MTcsImV4cCI6MTY3NDUxMDMxNywibmJmIjoxNjc0NDk5NTE3LCJqdGkiOiJseU1VbXBmbzhFQzZOTFJmIn0.AdRCRTZHCrmBW-drsVIZaoh8Ah81d8R-3hX7c825w7k'  
  const headers={
    'Api-key' : API_KEY, 
    'Content-Type' : 'application/json'
  };
  async function generateAccessTokenFetch() {
    const response = await axios.post( base + token, {
      method: "get",
      headers: { headers }
    });
    const data = await response.json();
    return console.log('data',data);
  }

  generateAccessTokenFetch()


  return (
    <>
        {}
    </>
  );
}

export default App;
